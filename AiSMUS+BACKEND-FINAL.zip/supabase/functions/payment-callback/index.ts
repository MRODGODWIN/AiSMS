import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type"};
Deno.serve(async(req)=>{
  if(req.method==='OPTIONS')return new Response('ok',{headers:cors});
  try{
    const u=new URL(req.url); const reference=u.searchParams.get('reference');
    if(!reference)return new Response('Missing payment reference',{status:400});
    const secret=Deno.env.get('PAYSTACK_SECRET_KEY'); if(!secret)throw new Error('PAYSTACK_SECRET_KEY is not configured');
    const supa=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const verify=await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`,{headers:{Authorization:`Bearer ${secret}`}});
    const result=await verify.json(); if(!verify.ok||!result.status)throw new Error(result.message||'Payment verification failed');
    const tx=result.data; const {data:payment}=await supa.from('payments').select('id,order_id,amount,currency').eq('reference',reference).maybeSingle();
    if(!payment)throw new Error('Payment record not found');
    const expected=Math.round(Number(payment.amount)*100);
    const paid=tx.status==='success' && Number(tx.amount)===expected && tx.currency===payment.currency;
    await supa.from('payments').update({status:paid?'paid':'failed'}).eq('id',payment.id);
    await supa.from('orders').update({payment_status:paid?'paid':'failed',status:paid?'paid':'pending'}).eq('id',payment.order_id);
    return Response.redirect(u.origin+u.pathname.replace('/payment-callback','')+'?payment='+(paid?'success':'failed')+'&reference='+encodeURIComponent(reference),303);
  }catch(e){return new Response(e?.message||String(e),{status:500,headers:{'Content-Type':'text/plain'}})}
});
