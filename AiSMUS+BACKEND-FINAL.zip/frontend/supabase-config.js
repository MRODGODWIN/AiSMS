// AiSMS+BACKEND Supabase configuration.
// Put this file beside index.html. Use ONLY the Supabase publishable/anon key here.
// Never put a service_role key in this file.
window.ASM_SUPABASE_URL = window.ASM_SUPABASE_URL || 'YOUR_SUPABASE_PROJECT_URL';
window.ASM_SUPABASE_PUBLISHABLE_KEY = window.ASM_SUPABASE_PUBLISHABLE_KEY || 'YOUR_SUPABASE_PUBLISHABLE_KEY';
