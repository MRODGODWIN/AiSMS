import "jsr:@supabase/functions-js/edge-runtime.d.ts";

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed",{status:405});
  const auth = req.headers.get("Authorization");
  if (!auth) return new Response(JSON.stringify({error:"Authentication required"}),{
    status:401,headers:{"Content-Type":"application/json"}
  });
  const body = await req.json();
  if (!body.subject) return new Response(JSON.stringify({error:"subject is required"}),{
    status:400,headers:{"Content-Type":"application/json"}
  });
  // Frontend may use the protected service_requests table directly.
  // This function is reserved for future email/WhatsApp notification fan-out.
  return new Response(JSON.stringify({ok:true}),{
    status:200,headers:{"Content-Type":"application/json"}
  });
});
