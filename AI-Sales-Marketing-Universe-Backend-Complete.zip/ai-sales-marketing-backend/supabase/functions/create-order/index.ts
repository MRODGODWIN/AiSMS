import "jsr:@supabase/functions-js/edge-runtime.d.ts";

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed",{status:405});
  return new Response(JSON.stringify({
    message:"Order creation is intentionally implemented as a Postgres RPC in this package.",
    next:"Call public.create_order_from_cart from an authenticated client."
  }),{status:200,headers:{"Content-Type":"application/json"}});
});
